# v1.xx.x - yyyy-mm-dd

This is an example file.
The changes should go to changelog.md!

## Changes affecting backward compatibility

- `foo` now behaves differently, use `-d:nimLegacyFoo` for previous behavior.

## Standard library additions and changes

- Added `example.exampleProc`.

- Changed `example.foo` to take additional `bar` parameter.

## Language changes


## Compiler changes


## Tool changes

