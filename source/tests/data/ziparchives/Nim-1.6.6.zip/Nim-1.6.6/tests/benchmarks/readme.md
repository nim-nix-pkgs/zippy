# Collection of benchmarks

In future work, benchmarks can be added to CI, but for now we provide benchmarks that can be run locally.

See RFC: https://github.com/timotheecour/Nim/issues/425
