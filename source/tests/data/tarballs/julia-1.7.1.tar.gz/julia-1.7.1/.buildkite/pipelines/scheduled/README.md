## Scheduled pipeline (`master` branch only)

This is the [`julia-master->scheduled`](https://buildkite.com/julialang/julia-master-scheduled) pipeline.

We use this pipeline for scheduled builds. The builders in this pipeline run on a schedule once per day. They are not triggered by GitHub webhooks.
