## Experimental pipeline (`master` branch only)

This is the [`julia-master->experimental`](https://buildkite.com/julialang/julia-master-experimental) pipeline.

We use this pipeline for builders that are not yet stable enough to go into the main pipeline.

These builders are triggered by GitHub webhook events, such as pushes and pull requests.
