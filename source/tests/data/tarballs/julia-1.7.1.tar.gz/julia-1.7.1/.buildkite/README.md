# Buildkite

This directory contains the Buildkite configuration files for Base Julia CI.

The rootfs image definitions are located in the [rootfs-images](https://github.com/JuliaCI/rootfs-images) repository.

The documentation for the Base Julia CI setup is located in the [base-buildkite-docs](https://github.com/JuliaCI/base-buildkite-docs) repository.
