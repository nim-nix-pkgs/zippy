# Iteration utilities

```@docs
Base.Iterators.Stateful
Base.Iterators.zip
Base.Iterators.enumerate
Base.Iterators.rest
Base.Iterators.countfrom
Base.Iterators.take
Base.Iterators.takewhile
Base.Iterators.drop
Base.Iterators.dropwhile
Base.Iterators.cycle
Base.Iterators.repeated
Base.Iterators.product
Base.Iterators.flatten
Base.Iterators.partition
Base.Iterators.map
Base.Iterators.filter
Base.Iterators.accumulate
Base.Iterators.reverse
Base.Iterators.only
Base.Iterators.peel
```
